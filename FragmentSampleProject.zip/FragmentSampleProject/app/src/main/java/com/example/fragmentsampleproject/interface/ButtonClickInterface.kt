package com.example.fragmentsampleproject.`interface`

interface ButtonClickInterface {
    fun updateQuestionNumber(text: Int)
}